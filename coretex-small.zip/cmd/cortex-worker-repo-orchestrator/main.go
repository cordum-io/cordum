package main

import "github.com/yaront1111/cortex-os/packages/workflows/repo"

func main() {
	repo.Run()
}
