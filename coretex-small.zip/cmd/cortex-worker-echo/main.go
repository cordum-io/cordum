package main

import "github.com/yaront1111/cortex-os/packages/workers/echo"

func main() {
	echo.Run()
}
