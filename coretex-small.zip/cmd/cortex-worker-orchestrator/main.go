package main

import "github.com/yaront1111/cortex-os/packages/workflows/demo"

func main() {
	demo.Run()
}
