package main

import "github.com/yaront1111/cortex-os/packages/workers/repo/partition"

func main() {
	partition.Run()
}
