package main

import "github.com/yaront1111/cortex-os/packages/workers/repo/tests"

func main() {
	tests.Run()
}
