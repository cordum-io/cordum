package main

import "github.com/yaront1111/cortex-os/packages/workers/codellm"

func main() {
	codellm.Run()
}
