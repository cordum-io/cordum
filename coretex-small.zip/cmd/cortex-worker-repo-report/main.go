package main

import "github.com/yaront1111/cortex-os/packages/workers/repo/report"

func main() {
	report.Run()
}
